%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%lecture de l'ensemble des images de la s�quence
%im=lecture_sequence()
SEQUENCE = './seq2/';
START = 1;
% chargement du nom des images de la sequence
filenames = dir([SEQUENCE '*.png']);
filenames = sort({filenames.name});
T = length(filenames);

%%Initialisation des param�tres
global N 
N=100;
global Nb
Nb=10;
global lambda
lambda=20;
global c1
c1=300;
global c2
c2=300;
global c3
c3=2;

% chargement de la premiere image
tt = START;
im = imread([SEQUENCE filenames{tt}]);
%%Affichage de la premi�re image
figure;
set(gcf,'DoubleBuffer','on');
imagesc(im);


%%Selection de la zone a suivre :
disp('Cliquer 4 points dans l��image pour definir la zone a suivre.');

zone = zeros(2,4);
compteur=1;
while(compteur ~= 5)
[x,y,button] = ginput(1);
zone(1,compteur) = x;
zone(2,compteur) = y;
text(x,y,'X','Color','r');
compteur = compteur+1;
end
newzone = zeros(2,4);
newzone(1,:) = sort(zone(1,:));
newzone(2,:) = sort(zone(2,:));
% definition des parametres de la zone a suivre x haut gauche, y haut gauche, largeur, hauteur
zoneAT = zeros(1,4);
zoneAT(1) = newzone(1,1);%zoneAT[1]=coordonn�e x du point le plus a gauche
zoneAT(2) = newzone(2,1);%zoneAT[2]=coordonnee y du point le plus vers le haut
zoneAT(3) = newzone(1,4)-newzone(1,1);%zoneAT[3]=largeur
zoneAT(4) = newzone(2,4)-newzone(2,1);%zoneAT[4]=hauteur
% Affichage de la zone a suivre
rectangle('Position',zoneAT,'EdgeColor','r','LineWidth',3);
figure;
%%centre x+largeur/2 et y-hauteur/2


%Construction d�un histogramme de couleur sur la zone � suivre
littleim = imcrop(im,zoneAT(1:4));
[~,Cmap] = rgb2ind(littleim,Nb,'nodither');

littleim = rgb2ind(littleim,Cmap,'nodither');

histoRef = imhist(littleim,Cmap);
histoRef = histoRef/sum(histoRef);
% affichage de l�histogramme
figure;
imhist(littleim,Cmap);


%%%Initialisation des particules
x_ini=zoneAT(1)
y_ini=zoneAT(2)
s_ini=100;
largeur=zoneAT(3)
hauteur=zoneAT(4)

mu_ini=[x_ini,y_ini,s_ini];
Sigma_ini=2*eye(3);

particles= mvnrnd(mu_ini,Sigma_ini,N); %matrice de N particules (chaque ligne taille 3)

%%%%%%BOUCLE WHILE
compteur=0;
for k=1:T
    %%Filtrage SIR (R�echantillonage,Prediction, correction)
    %%Diffusion des particules
    %%Prediction
    particles_ancien=particles;
    particles=particles+mvnrnd(zeros(1,3),diag([c1,c2,c3]),N);
    for i=1:N
        while(particles(i,3)<=0)
            particles(i,3)=particles_ancien(i,3)+mvnrnd(0,c3);  %%L' �chelle ne peut pas �tre n�gative
        end
    end
    %%Calcul histogramme
    List_histo_k=[];
    List_zoneAT_p=[];
    imk=imread([SEQUENCE filenames{k}]);
    for i=1:N
        zoneAT_p=zeros(1,4);
        while((particles(i,1)+largeur*particles(i,3)/100)>512 || particles(i,1)<0 || (particles(i,2)+hauteur*particles(i,3)/100)>384 || particles(i,2)<0)
            particles(i,1)=particles_ancien(i,1)+mvnrnd(0,c1);
            particles(i,2)=particles_ancien(i,2)+mvnrnd(0,c2);
        end
        zoneAT_p(1)=particles(i,1);
        zoneAT_p(2)=particles(i,2);
        zoneAT_p(3)=largeur*particles(i,3)/100;
        zoneAT_p(4)=hauteur*particles(i,3)/100;
        List_zoneAT_p=[List_zoneAT_p;zoneAT_p];
        List_histo_k = [List_histo_k;transpose(calcul_histo(imk,zoneAT_p,Cmap))];
    end
    
    %%Calcul et normalisation des poids des particules
    %%Correction
    wk=compute_weights(histoRef,List_histo_k,lambda,N); %calcul poids d importance + normalisation

    %%Affichage particules

    imshow(imk)
    for i = 1:N
        rectangle('Position',List_zoneAT_p(i,:),'EdgeColor','b','LineWidth',0.5);
    end

    %%Affichage estimation
    sumwk=sum(wk);
    wk=wk/sumwk;
    zoneAT_estim=zeros(1,4);
    zoneAT_estim(1)=dot(List_zoneAT_p(:,1),wk);
    zoneAT_estim(2)=dot(List_zoneAT_p(:,2),wk);
    zoneAT_estim(3)=dot(List_zoneAT_p(:,3),wk);
    zoneAT_estim(4)=dot(List_zoneAT_p(:,4),wk);
    
    rectangle('Position',zoneAT_estim,'EdgeColor','y','LineWidth',3);
    figure
    %%Re-sampling
    [particles,~,~] = fct_multi(transpose(particles),wk,N); %Les N particles redistribu�es
    particles=transpose(particles);
    compteur=compteur+1;
    %compteur
    
    
end






