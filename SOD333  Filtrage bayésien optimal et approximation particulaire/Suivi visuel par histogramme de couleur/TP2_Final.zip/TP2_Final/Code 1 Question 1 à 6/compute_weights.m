function [wk]= compute_weights(q,List_histo_k,lambda,N)
%Calcul et normalisation des poids
wk=[];
for i=1:N
    wk=[wk,exp(-lambda*(distance(q,List_histo_k(i,:))^2))];
end
sumwk=sum(wk);
wk=wk./sumwk;%normalisation

