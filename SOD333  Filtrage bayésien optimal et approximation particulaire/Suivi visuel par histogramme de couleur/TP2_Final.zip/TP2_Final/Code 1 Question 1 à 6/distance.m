function[dist]=distance(q1,q2)
%calcul de la distance entre 2 histogrammes q1 et q2
pdt=q1.*transpose(q2);
dist=sum(sqrt(pdt));
dist=1-dist;
dist=sqrt(dist);