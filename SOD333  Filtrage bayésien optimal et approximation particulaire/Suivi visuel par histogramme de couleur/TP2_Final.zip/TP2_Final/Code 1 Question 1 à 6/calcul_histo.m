%%%Construction Affichage et Calcul de l'histogramme pour une particule de
%%%zoneAt donn�e
function [histo] = calcul_histo(imk,zoneAT,map)

%calcul de l�histogramme associe a chaque particule
impart=imcrop(imk,zoneAT(1:4));
impart = rgb2ind(impart,map,'nodither');%impart est l'image correspondant au rectangle defini par la particule
%imshow(littleim)
histo = imhist(impart,map);
histo = histo/sum(histo);%normalisation