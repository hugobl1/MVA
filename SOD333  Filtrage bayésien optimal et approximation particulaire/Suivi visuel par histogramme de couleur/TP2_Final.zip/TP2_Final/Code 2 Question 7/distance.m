function[dist]=distance(q1,q2)
%%fonction qui calcule la distance entre 2 histogrammes
pdt=q1.*transpose(q2);
dist=sum(sqrt(pdt));
dist=1-dist;
dist=sqrt(dist);